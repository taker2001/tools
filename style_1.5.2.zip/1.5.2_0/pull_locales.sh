ruby pull_locales.rb
python fill_locale_placeholders.py
