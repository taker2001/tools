import os
path = '/Users/romeo/Downloads'
files = os.listdir(path)

for f in files:
    if 'Java' in f and f.endswith('.pdf'):
        print('Found it! ' + f)