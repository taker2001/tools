import os
import shutil

path = '/Users/romeo/Downloads/'
files = os.listdir(path)

for f in files:
    # f.png
    # ./png/
    folder_name = f.split('.')[-1]
    if not os.path.exists(path + folder_name):
        os.makedirs(path + folder_name)
        shutil.move(path + f, path + folder_name)
    else:
        shutil.move(path + f, path + folder_name)




