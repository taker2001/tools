# 记录生肖，根据年份来判断生肖

chinese_zodiac = '猴鸡狗🐷鼠牛虎兔龙蛇马羊'

# year = 1969
# year = int(input('请输入出生年份：'))

# if (chinese_zodiac[year % 12]) == '牛':
#     print('牛年运势：好！！！')

for cz in chinese_zodiac:
    print(cz)