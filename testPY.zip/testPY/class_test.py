# user1 = {'name': 'tom', 'hp': 100}
# user2 = {'name': 'jerry', 'hp': 80}
#
#
# def print_role(rolename):
#     print('name is %s , hp is %s' % (rolename['name'], rolename['hp']))
#
#
# print_role(user1)


class Player():
    def __init__(self, name, hp, occu):
        self.name = name
        self.hp = hp
        self.occu = occu

    def print_role(self):
        print('%s : %s %s' % (self.name, self.hp, self.occu))

    def updateName(self, newname):
        self.name = newname


class Monster():
    'define monster'
    def __init__(self, hp=100):
        self.hp = hp

    def run(self):
        print('Moved to ...')

    def whoami(self):
        print('Im Monster parent')


class Animals(Monster):
    'normal monster'
    def __init__(self, hp=10):
        super().__init__(hp)



class Boss(Monster):
    'boss'
    def __init__(self, hp=1000):
        super().__init__(hp)

    def whoami(self):
        print('Im boss')

a1 = Monster(200)
print(a1.hp)
print(a1.run())

a2 = Animals(1)
print(a2.hp)
print(a2.run())

a3 = Boss(800)
a3.whoami()

print('a1的类型是 %s' %(type(a1)))
print('a2的类型是 %s' %(type(a2)))
print('a3的类型是 %s' %(type(a3)))
print(isinstance(a2, Boss))

# user1 = Player('tom', 100, 'war')
# user2 = Player('jerry', 80, 'master')
# user1.print_role()
# user2.print_role()
#
# user1.updateName('Romeo')
# user1.print_role()
