import re

p = re.compile('(\d+)-(\d+)-(\d+)')
# print(p.match('2018-07-03').group(1))
# print(p.match('2018-07-03').groups())

print(p.search('aa2018-07-03'))

phone = '186-0204-2323 # this is phone number'
p2 = re.sub(r'#.*$', '', phone)
print(p2)

p3 = re.sub(r'\D','',phone)
print(p3)

