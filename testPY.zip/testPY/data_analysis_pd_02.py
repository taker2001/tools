import os
import pandas as pd
import matplotlib.pyplot as plt

datafile_path = './data/Beijing_PM.csv'

output_path = './output'
if not os.path.exists(output_path):
    os.makedirs(output_path)


def collect_data():
    data_df = pd.read_csv(datafile_path)
    return data_df


def inspect_data(data_df):
    print('数据共有{}行，{}列'.format(data_df.shape[0], data_df.shape[1]))
    print('数据预览：')
    print(data_df.head())
    print('数据基本信息：')
    print(data_df.info())
    print('数据统计信息：')
    print(data_df.describe())


def process_data(data_df):
    # Process null values
    cln_data_df = data_df.dropna()

    # filter by year
    # cond = (cln_data_df['Year'] >= 2005) & (cln_data_df['Year'] <= 2017)
    # cln_data_df1 = cln_data_df[cond]
    filtered_data_df = cln_data_df.copy()

    filtered_data_df['Diff'] = filtered_data_df['PM_China'].abs() - filtered_data_df['PM_US'].abs()

    print('原始数据有{}行记录，处理后的数据有{}行记录'.format(data_df.shape[0], filtered_data_df.shape[0]))
    return filtered_data_df


def analyze_data(data_df):
    top10_diffs = data_df.sort_values(by='Diff', ascending=False).head(10)
    # filtered_data_df = data_df[['Global_Sales'] > 5]
    grouped_df = data_df.groupby('year')
    comp_results = grouped_df[['PM_China', 'PM_US']].mean()

    return top10_diffs, comp_results


def save_and_show_results(top10_diffs, comp_results):
    top10_diffs.to_csv(os.path.join(output_path, 'top10_diffs.csv'), index=False)
    comp_results.to_csv(os.path.join(output_path, 'comp_results.csv'))

    # top10_diffs.plot(kind='bar', x='year', y='Diff')
    # plt.title('Top 10 Diff PM 2.5)')
    # plt.tight_layout()
    # plt.savefig(os.path.join(output_path, 'top10_diffs.png'))
    # plt.show()

    comp_results.plot(kind='bar')
    plt.title('PM 2.5 China-US Comparison')
    plt.tight_layout()
    plt.savefig(os.path.join(output_path, 'comp_results.png'))
    plt.show()


def main():
    data_df = collect_data()

    inspect_data(data_df)

    proc_data_df = process_data(data_df)

    top10_diffs, comp_results = analyze_data(proc_data_df)

    save_and_show_results(top10_diffs, comp_results)

if __name__ == '__main__':
    main()

