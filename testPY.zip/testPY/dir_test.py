import os
print(os.path.abspath('.'))
print(os.path.exists('/Users/romeo'))
print(os.path.isdir('/Users/romeo'))

from pathlib import Path
p = Path('.')
print(p.resolve())

q = Path('/tmp/a/b')
Path.mkdir(q,parents=True)