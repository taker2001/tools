while True:
    print('Give a number')
    num = input()
    try:
        print(20/int(num))

    except ValueError:
        print('Invalid number, input should be integer')
    except ZeroDivisionError:
        print('Dont input ZERO')

