# i = j


# print())


# a='123'
# print(a[3])

# d = {'a': 1, 'b': 2}
# print(d['c'])

# try:
#     year = int(input('input year:'))
# except ValueError:
#     print('年份要输入数字')

# a=123
# a.append()

# try:
#     print(1/0)
# except Exception as e:
#     print('0不能做除数 %s' %e)

try:
    a = open('name_old.txt')
except Exception as e:
    print('Failed to open file %s' %e)

finally:
    a.close()

