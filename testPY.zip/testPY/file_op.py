# 将小说的主要人物记录在文件中
# file1 = open('name_old.txt', 'w', encoding='utf-8')
# file1.write('诸葛亮')
# file1.close()
#
# file2 = open('name_old.txt', encoding='utf-8')
# print(file2.read())
# file2.close()
#
# file3 = open('name_old.txt', 'a', encoding='utf-8')
# file3.write('刘备')
# file3.close()

# file4 = open('name_old.txt', encoding='utf-8')
# print(file4.readline())
# file4.close()
#
# file5 = open('name_old.txt', encoding='utf-8')
# for line in file5.readlines():
#     print(line)
#     print('========')

file6 = open('name_old.txt', encoding='utf-8')
print("当前文件指针位置：%s" %file6.tell())
print("当前读取内容：%s" %file6.read(1))
print("当前文件指针位置：%s" %file6.tell())
file6.seek(5, 0)
print("我们进行了seek操作")
print("当前文件指针位置：%s" %file6.tell())
file6.close()