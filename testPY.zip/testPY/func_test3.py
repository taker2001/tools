def a_line(a, b):
    def arg_y(x):
        return a * x + b
    return arg_y


def b_line(a, b):
    return lambda x: a * x + b


# a=3, b=5, x=10, y=?

# line1 = a_line(3,5)
# print(line1(10))

line2 = b_line(3,5)
print(line2(10))