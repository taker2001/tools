import mymod

mymod.print_me()

