def print_me():
    print('me')

# print_me()