import requests
import re

content = requests.get('http://www.cnu.cc/discoveryPage/hot-人像').text
print(content)