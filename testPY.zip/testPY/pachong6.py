from bs4 import BeautifulSoup
import requests

url = 'http://www.infoq.com/cn/news'

def craw2(ur):
    response = requests.get(url)

    soup = BeautifulSoup(response.text, 'lxml')

    for title_href in soup.find_all('div', class_='news_type_block'):
        print([title.get('title')
              for title in title_href.find_all('a') if title.get('title')])

craw2(url)