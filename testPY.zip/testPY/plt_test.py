import matplotlib.pyplot as plt

# plt.plot([1, 3, 5], [4, 8, 10])
#
# # plt.plot(['20180705', '20180707', '20180714'], ['38339870', '38339871', '38339872'])
# plt.show()

import numpy as np

# x = np.linspace(-np.pi, np.pi, 100)
# plt.plot(x, np.sin(x))
# plt.show()

x = ['20180705', '20180707', '20180714']
y = ['38339870', '38339871', '38339872']
fig = plt.figure()
plt.scatter(x,y)
plt.show()

