# 读取人物名称
# f = open('name.txt', encoding='utf-8')
# data = f.read()
# print(data.split('|'))

# 读取兵器名称
# f2 = open('weapon.txt', encoding='utf-8')
#
# i = 1
# for line in f2.readlines():
#     if i % 2 == 1:
#         print(line.strip('\n'))
#     i += 1
# f2.close()

# f3 = open('sanguo.txt', encoding='GB18030')
# print(f3.read().replace('\n',''))
# f3.close()


def func(filename):
    print(open(filename, encoding='utf-8').read())
    print('test func')

func('name.txt')
