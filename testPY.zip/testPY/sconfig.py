CONFIGS = [
    {
        'name':'WORK',
        'folders':[
            # source
            '/Users/romeo/Downloads/pdf',
            '/Users/romeo/Downloads/ppt',
            '/Users/romeo/Downloads/FRM'
        ],
        'target':'/Users/romeo/Desktop/'
    },
    {
        'name':'PLAY',
        'folders':[
            '/Users/romeo/Music'
        ],
        'target':'/Users/romeo/Desktop/'
    }
]