import random
print(random.randint(1,5))
print(random.choice(['aa','bb','cc']))

