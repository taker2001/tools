dict1 = {}
print(type(dict1))
dict2 = {'x': 1, 'y': 2, 'z': 3}

print(dict2)

