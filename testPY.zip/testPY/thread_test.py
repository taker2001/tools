import threading
import time
from threading import current_thread


def myThread(arg1, arg2):
    print(current_thread().getName(), 'Start')
    print('%s %s' % (arg1, arg2))
    time.sleep(2)
    print(current_thread().getName(), 'End')


for i in range(1, 6):
    # t1 = myThread(i, i+1)
    t1 = threading.Thread(target=myThread, args=(i, i + 1))
    t1.start()

print(current_thread().getName(), 'End')
