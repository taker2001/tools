import time
import datetime

# print(time.localtime())
# print(time.strftime('%Y-%m-%d %H:%M:%S'))

print(datetime.datetime.now())
newtime = datetime.timedelta(minutes=10)
print(datetime.datetime.now() + newtime)

one_day = datetime.datetime(2018,7,14)
new_date = datetime.timedelta(days=1)
print(one_day - new_date)
