import numpy as np

# 1 Read csv data file
data_arr = np.loadtxt('./temp.csv', delimiter=',', dtype='str', skiprows=1)

# 2 get the first column
c_temp_str_col = data_arr[:, 1]

# 3 global replace the string removing C
cln_c_temp_str_col = np.core.defchararray.replace(c_temp_str_col, ' C', '')

# 4 Convert type
c_temp_col = cln_c_temp_str_col.astype('float')

# 5 Formulae
f_temp_col = 1.8 * c_temp_col + 32

print('摄氏温度数据：')
print(c_temp_col)

print('转换后的华氏温度数据：')
print(f_temp_col)


