# build space -> choose space -> switch space
# How we start OOP? -> space

from subprocess import call
import os
from sconfig import CONFIGS

class WorkSpace:

    def __init__(self, c):
        self.folders = c['folders']
        self.name    = c['name']
        self.target  = c['target']

    def switch(self):

        for f in os.listdir(self.target):
            if f.endswith('.wspc'):
                path = self.target + f
                os.remove(path)

        # mklink
        for source in self.folders:
            real_target = self.target + source.split('/')[-1] + '.wspc'
            command = ['ln', '-s', source, real_target]
            call(command)


workspaces = [WorkSpace(c) for c in CONFIGS]
print('Choose your workspace:')
choice = input()
for w in workspaces:
    if w.name == choice:
        w.switch()

